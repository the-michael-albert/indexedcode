pub trait Shape0 {
    fn area(&self) -> f64;

    fn describe(&self) -> String {
        format!("shape-{}", self.area())
    }
}

pub struct Circle0 {
    pub radius: f64,
}

impl Shape0 for Circle0 {
    fn area(&self) -> f64 {
        3.14159 * self.radius * self.radius
    }
}

pub fn make_circle0(radius: f64) -> Circle0 {
    Circle0 { radius }
}
