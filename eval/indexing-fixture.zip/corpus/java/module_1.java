package demo1;

public abstract class Device1 {
    protected final String id;

    public Device1(String id) {
        this.id = id;
    }

    public abstract String read();

    public String describe() {
        return id + ":" + read();
    }
}

class Sensor1 extends Device1 {
    public Sensor1(String id) {
        super(id);
    }

    @Override
    public String read() {
        return "value";
    }
}
