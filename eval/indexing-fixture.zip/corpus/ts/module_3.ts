export interface Repository3 {
  find(id: string): Promise<Record<string, unknown>>;
  save(entity: Record<string, unknown>): Promise<void>;
}

export abstract class BaseRepository3 implements Repository3 {
  protected prefix = "repo3";

  abstract find(id: string): Promise<Record<string, unknown>>;

  async save(entity: Record<string, unknown>): Promise<void> {
    await this.find(String(entity.id ?? "new"));
  }

  describe(): string {
    return `${this.prefix} repository`;
  }
}

export class SqlRepository3 extends BaseRepository3 {
  async find(id: string): Promise<Record<string, unknown>> {
    return { id, prefix: this.prefix };
  }
}

export function createRepository3(): Repository3 {
  return new SqlRepository3();
}

export const arrowHandler3 = async (input: string) => input.toUpperCase();
