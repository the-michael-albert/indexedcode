class Node0 {
public:
    virtual ~Node0() = default;
    virtual int evaluate() const = 0;
};

class Constant0 : public Node0 {
    int value;

public:
    explicit Constant0(int v) : value(v) {}

    int evaluate() const override { return value; }
};

inline int compute0(const Node0& node) { return node.evaluate(); }
