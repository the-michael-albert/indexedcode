package demo2;

public abstract class Device2 {
    protected final String id;

    public Device2(String id) {
        this.id = id;
    }

    public abstract String read();

    public String describe() {
        return id + ":" + read();
    }
}

class Sensor2 extends Device2 {
    public Sensor2(String id) {
        super(id);
    }

    @Override
    public String read() {
        return "value";
    }
}
