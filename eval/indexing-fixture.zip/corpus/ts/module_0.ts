export interface Repository0 {
  find(id: string): Promise<Record<string, unknown>>;
  save(entity: Record<string, unknown>): Promise<void>;
}

export abstract class BaseRepository0 implements Repository0 {
  protected prefix = "repo0";

  abstract find(id: string): Promise<Record<string, unknown>>;

  async save(entity: Record<string, unknown>): Promise<void> {
    await this.find(String(entity.id ?? "new"));
  }

  describe(): string {
    return `${this.prefix} repository`;
  }
}

export class SqlRepository0 extends BaseRepository0 {
  async find(id: string): Promise<Record<string, unknown>> {
    return { id, prefix: this.prefix };
  }
}

export function createRepository0(): Repository0 {
  return new SqlRepository0();
}

export const arrowHandler0 = async (input: string) => input.toUpperCase();
