import json
import logging
from abc import ABC, abstractmethod

LOGGER = logging.getLogger(__name__)


class AbstractService7(ABC):
    """Abstract service contract #7."""

    def __init__(self, name: str):
        self._name = name

    @abstractmethod
    def handle(self, payload: dict) -> dict:
        """Process one payload."""

    @abstractmethod
    def name(self) -> str:
        """Return the service name."""


class ConcreteService7A(AbstractService7):
    def handle(self, payload: dict) -> dict:
        LOGGER.debug("handling %s", payload)
        return dict(sorted(payload.items()))

    def name(self) -> str:
        return f"{self._name}-a"


class ConcreteService7B(AbstractService7):
    def handle(self, payload: dict) -> dict:
        merged = {**payload, "service": self.name()}
        return merged

    def name(self) -> str:
        return f"{self._name}-b"


def dispatch7(service: AbstractService7, events: list) -> list:
    results = []
    for event in events:
        results.append(service.handle(json.loads(json.dumps(event))))
    return results


def summarize7(results: list) -> dict:
    return {"count": len(results), "ok": all(r is not None for r in results)}
