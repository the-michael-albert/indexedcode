# Indexing fixture corpus

Deterministic generated corpus for testing IndexedCode end-to-end.

- Python: ABC-based abstract services, two concrete subclasses each,
  module functions, a test file importing them.
- TypeScript: interfaces, abstract base classes, `implements`/`extends`,
  async methods, arrow functions.
- Java: abstract classes with abstract methods and subclasses.
- Go: structs with receiver methods and an interface.
- Rust: traits with default methods and `impl` blocks.
- C++: virtual abstract classes with inheritance.
- JavaScript: `class extends` hierarchies and arrow functions.
