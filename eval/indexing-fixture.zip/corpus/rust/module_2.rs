pub trait Shape2 {
    fn area(&self) -> f64;

    fn describe(&self) -> String {
        format!("shape-{}", self.area())
    }
}

pub struct Circle2 {
    pub radius: f64,
}

impl Shape2 for Circle2 {
    fn area(&self) -> f64 {
        3.14159 * self.radius * self.radius
    }
}

pub fn make_circle2(radius: f64) -> Circle2 {
    Circle2 { radius }
}
