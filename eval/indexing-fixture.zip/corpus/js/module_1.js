export class Animal1 {
  constructor(name) {
    this.name = name;
  }

  speak() {
    return `${this.name} makes a sound`;
  }
}

export class Dog1 extends Animal1 {
  speak() {
    return `${this.name} barks`;
  }
}

export function adopt1(animal) {
  return animal.speak();
}

export const feed1 = (animal) => animal.name;
