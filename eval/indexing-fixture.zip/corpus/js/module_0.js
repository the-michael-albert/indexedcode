export class Animal0 {
  constructor(name) {
    this.name = name;
  }

  speak() {
    return `${this.name} makes a sound`;
  }
}

export class Dog0 extends Animal0 {
  speak() {
    return `${this.name} barks`;
  }
}

export function adopt0(animal) {
  return animal.speak();
}

export const feed0 = (animal) => animal.name;
