import json
import logging
from abc import ABC, abstractmethod

LOGGER = logging.getLogger(__name__)


class AbstractService1(ABC):
    """Abstract service contract #1."""

    def __init__(self, name: str):
        self._name = name

    @abstractmethod
    def handle(self, payload: dict) -> dict:
        """Process one payload."""

    @abstractmethod
    def name(self) -> str:
        """Return the service name."""


class ConcreteService1A(AbstractService1):
    def handle(self, payload: dict) -> dict:
        LOGGER.debug("handling %s", payload)
        return dict(sorted(payload.items()))

    def name(self) -> str:
        return f"{self._name}-a"


class ConcreteService1B(AbstractService1):
    def handle(self, payload: dict) -> dict:
        merged = {**payload, "service": self.name()}
        return merged

    def name(self) -> str:
        return f"{self._name}-b"


def dispatch1(service: AbstractService1, events: list) -> list:
    results = []
    for event in events:
        results.append(service.handle(json.loads(json.dumps(event))))
    return results


def summarize1(results: list) -> dict:
    return {"count": len(results), "ok": all(r is not None for r in results)}
