class Node2 {
public:
    virtual ~Node2() = default;
    virtual int evaluate() const = 0;
};

class Constant2 : public Node2 {
    int value;

public:
    explicit Constant2(int v) : value(v) {}

    int evaluate() const override { return value; }
};

inline int compute2(const Node2& node) { return node.evaluate(); }
