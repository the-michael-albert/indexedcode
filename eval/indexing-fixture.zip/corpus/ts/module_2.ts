export interface Repository2 {
  find(id: string): Promise<Record<string, unknown>>;
  save(entity: Record<string, unknown>): Promise<void>;
}

export abstract class BaseRepository2 implements Repository2 {
  protected prefix = "repo2";

  abstract find(id: string): Promise<Record<string, unknown>>;

  async save(entity: Record<string, unknown>): Promise<void> {
    await this.find(String(entity.id ?? "new"));
  }

  describe(): string {
    return `${this.prefix} repository`;
  }
}

export class SqlRepository2 extends BaseRepository2 {
  async find(id: string): Promise<Record<string, unknown>> {
    return { id, prefix: this.prefix };
  }
}

export function createRepository2(): Repository2 {
  return new SqlRepository2();
}

export const arrowHandler2 = async (input: string) => input.toUpperCase();
