package store0

type Store0 struct {
	items map[string]string
}

func NewStore0() *Store0 {
	return &Store0{items: make(map[string]string)}
}

func (s *Store0) Put(key string, value string) {
	s.items[key] = value
}

func (s *Store0) Get(key string) string {
	return s.items[key]
}

type Loader0 interface {
	Load(key string) string
}
