package store2

type Store2 struct {
	items map[string]string
}

func NewStore2() *Store2 {
	return &Store2{items: make(map[string]string)}
}

func (s *Store2) Put(key string, value string) {
	s.items[key] = value
}

func (s *Store2) Get(key string) string {
	return s.items[key]
}

type Loader2 interface {
	Load(key string) string
}
