pub trait Shape1 {
    fn area(&self) -> f64;

    fn describe(&self) -> String {
        format!("shape-{}", self.area())
    }
}

pub struct Circle1 {
    pub radius: f64,
}

impl Shape1 for Circle1 {
    fn area(&self) -> f64 {
        3.14159 * self.radius * self.radius
    }
}

pub fn make_circle1(radius: f64) -> Circle1 {
    Circle1 { radius }
}
