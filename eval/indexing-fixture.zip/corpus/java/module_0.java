package demo0;

public abstract class Device0 {
    protected final String id;

    public Device0(String id) {
        this.id = id;
    }

    public abstract String read();

    public String describe() {
        return id + ":" + read();
    }
}

class Sensor0 extends Device0 {
    public Sensor0(String id) {
        super(id);
    }

    @Override
    public String read() {
        return "value";
    }
}
