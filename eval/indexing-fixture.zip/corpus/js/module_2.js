export class Animal2 {
  constructor(name) {
    this.name = name;
  }

  speak() {
    return `${this.name} makes a sound`;
  }
}

export class Dog2 extends Animal2 {
  speak() {
    return `${this.name} barks`;
  }
}

export function adopt2(animal) {
  return animal.speak();
}

export const feed2 = (animal) => animal.name;
