package store1

type Store1 struct {
	items map[string]string
}

func NewStore1() *Store1 {
	return &Store1{items: make(map[string]string)}
}

func (s *Store1) Put(key string, value string) {
	s.items[key] = value
}

func (s *Store1) Get(key string) string {
	return s.items[key]
}

type Loader1 interface {
	Load(key string) string
}
