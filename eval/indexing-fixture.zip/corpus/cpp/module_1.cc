class Node1 {
public:
    virtual ~Node1() = default;
    virtual int evaluate() const = 0;
};

class Constant1 : public Node1 {
    int value;

public:
    explicit Constant1(int v) : value(v) {}

    int evaluate() const override { return value; }
};

inline int compute1(const Node1& node) { return node.evaluate(); }
