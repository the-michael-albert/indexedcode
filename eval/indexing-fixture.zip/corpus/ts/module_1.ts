export interface Repository1 {
  find(id: string): Promise<Record<string, unknown>>;
  save(entity: Record<string, unknown>): Promise<void>;
}

export abstract class BaseRepository1 implements Repository1 {
  protected prefix = "repo1";

  abstract find(id: string): Promise<Record<string, unknown>>;

  async save(entity: Record<string, unknown>): Promise<void> {
    await this.find(String(entity.id ?? "new"));
  }

  describe(): string {
    return `${this.prefix} repository`;
  }
}

export class SqlRepository1 extends BaseRepository1 {
  async find(id: string): Promise<Record<string, unknown>> {
    return { id, prefix: this.prefix };
  }
}

export function createRepository1(): Repository1 {
  return new SqlRepository1();
}

export const arrowHandler1 = async (input: string) => input.toUpperCase();
