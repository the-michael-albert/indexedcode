from services.abstract_service_0 import (
    AbstractService0,
    ConcreteService0A,
    dispatch0,
    summarize0,
)


def test_dispatch_round_trip():
    service = ConcreteService0A("unit")
    results = dispatch0(service, [{{"a": 1}}, {{"b": 2}}])
    assert summarize0(results)["count"] == 2


def test_abstract_cannot_instantiate():
    try:
        AbstractService0("nope")
    except TypeError:
        return
    raise AssertionError("abstract class was instantiated")
